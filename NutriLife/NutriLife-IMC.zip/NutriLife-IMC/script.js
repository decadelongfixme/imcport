//this is awful but I need to ship. I've surprisingly managed to cut a LOT of rubbish in time, however.
function jni_imc(w,h){
	w = w / (h*h);
	return w;
}
function jni_lok(x){
	if (x < 16)
		return("Subpeso Severo");
	if (20 > x && x >=16)
		return("Subpeso");
	if (25 > x && x >= 20)
		return("Normal");
	if (30 > x && x >= 25)
		return("Sobrepeso");
	if (40 > x && x >= 30)
		return("Obeso");
	if (x >= 40)
		return("Obeso Mórbido");
}
function jni_prn() {
	var w = document.getElementById("peso").value;
	var h = document.getElementById("altura").value;
	if ( isNaN(w) || isNaN(h) || !(w > 0) || !(h > 0) ){
		document.getElementById("resultadoimc").setAttribute("value", "Valor inválido!");
		document.getElementById("avaliacaoimc").setAttribute("value", "");
	}
	else{
		var result_n = jni_imc(w,h);
		var result_t = jni_lok(result_n);
		document.getElementById("resultadoimc").setAttribute("value", result_n.toFixed(2)); // TODO: possibly problematic
		document.getElementById("avaliacaoimc").setAttribute("value", result_t);
	}
}